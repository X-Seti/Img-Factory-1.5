/*
 * Program ...... SinglePaint
 * File ......... SideBar.java
 * Author ....... Harald Hetzner
 * 
 * Copyright (C) 2006  Harald Hetzner
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
 * 
 * Harald Hetzner <singlepaint [at] mkultra [dot] dyndns [dot] org>
 */

package sp.swing;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import sp.Mediator;
import sp.Settings;

public class SideBar extends JPanel implements ActionListener, ChangeListener {

	public static final long serialVersionUID = 823462384L;

	private JSlider slider;
	private JTextField tfToolSize;

	private ToolTable toolTable;

	private ColorTable colorTable;
	
	private JButton buttonPost;
	
	private JButton buttonClear;

	public static final SideBar singleton = new SideBar();
	
	private SideBar() {
		this.init();
	}

	public void init() {
		this.slider = new JSlider(Settings.MIN_TOOL_SIZE,
				Settings.MAX_TOOL_SIZE, Mediator.singleton.getPainter().getToolSize());
		this.slider.addChangeListener(this);
		this.toolTable = new ToolTable();
		this.colorTable = new ColorTable();

		int cols = 2;
		this.tfToolSize = new JTextField(cols);
		this.tfToolSize.setHorizontalAlignment(JTextField.RIGHT);
		//this.tfToolSize.setEditable(false);
		this.tfToolSize.setEnabled(false);
		this.tfToolSize.setDisabledTextColor(Color.BLACK);
		this.tfToolSize.setText(Integer.toString(Mediator.singleton
				.getPainter().getToolSize()));
		this.tfToolSize.setMinimumSize(this.tfToolSize.getPreferredSize());
		this.tfToolSize.setMaximumSize(this.tfToolSize.getPreferredSize());
		
		this.buttonClear = new JButton("Clear");
		this.buttonClear.addActionListener(this);
		
		this.buttonPost = new JButton("Post");
		this.buttonPost.addActionListener(this);
		
		this.setLayout(new GridBagLayout());

		GridBagConstraints cPanel = new GridBagConstraints();
		cPanel.gridwidth = GridBagConstraints.REMAINDER;
		
		GridBagConstraints cSlider = new GridBagConstraints();
		cSlider.ipadx = 30;
		//cSlider.weightx = 0.5;
		cSlider.fill = GridBagConstraints.HORIZONTAL;
		cSlider.anchor = GridBagConstraints.WEST;
		
		GridBagConstraints cTf = new GridBagConstraints();
		cTf.insets = new Insets(10, 10, 10, 5);
		cTf.weightx = 1.0;
		cTf.fill = GridBagConstraints.NONE;
		cTf.anchor = GridBagConstraints.EAST;
		cTf.gridwidth = GridBagConstraints.REMAINDER;
		
		GridBagConstraints cTables = new GridBagConstraints();
		cTables.insets = new Insets(10, 10, 10, 10);
		cTables.fill = GridBagConstraints.NONE;
		cTables.gridwidth = GridBagConstraints.REMAINDER;
		
		GridBagConstraints cTool = new GridBagConstraints();
		cTool.insets = new Insets(20, 10, 5, 1);
		cTool.weightx = 0.5;
		cTool.anchor = GridBagConstraints.CENTER;
		
		GridBagConstraints cColor = new GridBagConstraints();
		cColor.insets = new Insets(20, 1, 5, 10);
		cColor.weightx = 0.5;
		cColor.anchor = GridBagConstraints.CENTER;
		cColor.gridwidth = GridBagConstraints.REMAINDER;
		

		GridBagConstraints cPost = new GridBagConstraints();
		cPost.insets = new Insets(10, 10, 10, 10);
		cPost.weighty = 1.0;
		cPost.anchor = GridBagConstraints.SOUTH;
		cPost.gridwidth = GridBagConstraints.REMAINDER;
		
		GridBagConstraints cClear = new GridBagConstraints();
		cClear.insets = new Insets(10, 10, 10, 10);
		cClear.anchor = GridBagConstraints.CENTER;
		cClear.gridwidth = GridBagConstraints.REMAINDER;

		
		JPanel panel1 = new JPanel();
		panel1.setLayout(new GridBagLayout());
		
		panel1.add(this.slider, cSlider);
		panel1.add(this.tfToolSize, cTf);
		this.add(panel1, cPanel);
		
		this.add(this.toolTable, cTables);
		this.add(this.colorTable, cTables);


		JPanel panel2 = new JPanel();
		panel2.setLayout(new GridBagLayout());
		
		panel2.add(this.toolTable.getToolLabel(), cTool);
		panel2.add(this.colorTable.getColorLabel(), cColor);
		this.add(panel2, cPanel);
		
		if (Settings.postURL != null) {
			this.add(this.buttonPost, cPost);
			this.add(this.buttonClear, cClear);
		}
		else {
			this.add(this.buttonClear, cPost);
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(this.buttonClear)) {
			Mediator.singleton.getPainter().clear();
		} else if (e.getSource().equals(this.buttonPost)) {
			Mediator.singleton.postImage();
		}
	}
	
	public void stateChanged(ChangeEvent e) {
		int value = this.slider.getValue();
		Mediator.singleton.getPainter().setToolSize(value);
		this.tfToolSize.setText(Integer.toString(value));
	}
}
