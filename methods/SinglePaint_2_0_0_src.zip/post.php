<?
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');

# adjust the paths to your needs
# the directories specified must exist
# the files will be created automatically
$fullsize_image_dir_path = 'posted/fullsize/';
$small_image_dir_path = 'posted/small/';
$count_file_path = 'posted/post.count';
$lock_file_path = 'posted/post.lock';
$log_file_path = 'posted/post.log';

# post.php can create a small (20%) of each image posted.
# the image will be saved at $small_image_dir_path
#
# for this feature to work php-gd needs to be installed
# to enable this feature, set create_small_images to true
#
create_small_images = false;
# create_small_images = true;

function unsetLock() {
	global $lock_file_path;
	unlink($lock_file_path);
}

function testAndSetLock() {
	global $lock_file_path;
	$seconds = 0;
	while (file_exists($lock_file_path)) {
		sleep(1);
		$seconds++;
		if ($seconds > 60) {
			unsetLock();
			break;
		}
   }
   $file = fopen($lock_file_path, 'w');
   fclose($file);
}

function getAndSetCount() {
	global $count_file_path;
	$count = -1;
	testAndSetLock();

	if (file_exists($count_file_path)) {
		$file = fopen($count_file_path, 'r');
		$count = fread($file, filesize($count_file_path));
		fclose($file);
	}
	else {
		$count = 0;
	}
	$file = fopen($count_file_path, 'w');
	fwrite($file, $count + 1);
	fclose($file);

	unsetLock();
	return $count;
}

function writeLog($message) {
	global $log_file_path;
	$line = '[ '.date('D M d H:i:s T Y').' ] '.$message."\n";
	$file = fopen($log_file_path, 'a');
	fwrite($file, $line);
	fclose($file);
}

# for this feature to work php-gd needs to be installed
function saveSmallImage($fname) {
	global $small_image_dir_path;
	global $fullsize_image_dir_path;

	$smallImagePath = $small_image_dir_path.$fname;
	$fullsizeImagePath = $fullsize_image_dir_path.$fname;

	$imgInfo = getimagesize($fullsizeImagePath);
	$fullsizeWidth = $imgInfo[0];
	$fullsizeHeight = $imgInfo[1];
	$smallWidth = $fullsizeWidth / 5;
	$smallHeight = $fullsizeHeight / 5;
	$fullsizeImage = imagecreatefrompng($fullsizeImagePath);
	$smallImage = imageCreate($smallWidth, $smallHeight);
	imagecopyresized($smallImage, $fullsizeImage, 0, 0, 0, 0, $smallWidth, $smallHeight, $fullsizeWidth, $fullsizeHeight);
	imagepng($smallImage, $smallImagePath);
}

function saveImage($data) {
    global $REMOTE_ADDR;
    global $fullsize_image_dir_path;

    $log_line = '';

	if ($data != '') {
		$image = base64_decode($data);
		$numb = getAndSetCount() + 1;
		$fname = $numb.'.png';
		$file = fopen($fullsize_image_dir_path.$fname, 'w');
		fwrite($file, $image);
		fclose($file);
		
		global $create_small_images;
		if ($create_small_images) {
			saveSmallImage($fname);
		}
		
		$logMessage = "Image ${numb} submitted by ${REMOTE_ADDR}";
	}
	else {
		$logMessage = "Submitting image failed for ${REMOTE_ADDR}";
	}
	writeLog($logMessage);
}

$img = $_POST['image'];
saveImage($img);
?>
